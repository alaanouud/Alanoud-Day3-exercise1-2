package com.example.task1;


import com.fasterxml.jackson.annotation.JsonTypeInfo;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;

@RestController
@RequestMapping("/api/v1")

public class Controller {
    ArrayList<task>  task1=new ArrayList<>();


    @GetMapping("/task")
    public ArrayList<task> gettask() {
        return task1;
    }

    @PostMapping ("/add")
    public ApiResponse addTask(@RequestBody task task){
        task1.add(task);
        return new ApiResponse("task added!");
    }

    @PutMapping("/update/{index}")
    public ApiResponse updateTask(@PathVariable int index, @RequestBody task task){
        task1.set(index,task);
        return new ApiResponse("task updated");
    } @PutMapping("/status/{index}/{status}")
    public ApiResponse updateStatus(@PathVariable int index, @PathVariable String status){

        task1.get(index).setStatus(status);
        return new ApiResponse("task updated");
    }
    @DeleteMapping("/delete/all")
    public ApiResponse deleteAllTask(){
        task1 = null;
        task1 = new ArrayList<>();
        return new ApiResponse("All data deleted");
    }

    @DeleteMapping("/delete/{index}")
    public ApiResponse deleteTask(@PathVariable int index){
        task1.remove(index);
        return new ApiResponse("task deleted!");
    }



    @GetMapping("/Change/task")
    public ApiResponse ChangeTasks(@PathVariable int index) {

         String  [] status = new String[]{"Done","Not done"};
        return new ApiResponse("tasks Change");

    }
    @GetMapping("/Search/task")
    public String randomTitle(){
        return randomTitle();
    }

    }




