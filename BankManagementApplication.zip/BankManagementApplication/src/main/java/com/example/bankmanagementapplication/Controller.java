package com.example.bankmanagementapplication;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1")
public class Controller {
    ArrayList<Customers> customers = new ArrayList<>();

    @GetMapping("/customers")
    public ArrayList<Customers> getCustomers(){
        return customers;
    }
    @GetMapping("/customer/{index}")
    public Customers getCustomer(@PathVariable int index){
        return customers.get(index);
    }

    @PostMapping ("/add")
    public ApiResponse addCustomer(@RequestBody Customers customer){
        customers.add(customer);
        return new ApiResponse("customer added!");
    }

    @PutMapping("/update/{index}")
    public ApiResponse updateCustomer(@PathVariable int index, @RequestBody Customers customer){

        customers.set(index,customer);
        return new ApiResponse("customer updated");
    }

    @DeleteMapping("/delete/all")
    public ApiResponse deleteCustomer(){
        customers = null;
        customers = new ArrayList<>();
        return new ApiResponse("All data deleted");
    }

    @DeleteMapping("/delete/{index}")
    public ApiResponse deleteCustomer(@PathVariable int index){
        customers.remove(index);
        return new ApiResponse("customer deleted!");
    }

    @PutMapping("/deposit/{amount}/{ID}")
    public ApiResponse depositMony(@PathVariable int amount ,@PathVariable int ID){
        customers.get(ID).setBalance( customers.get(ID).getBalance() + amount);
        return new ApiResponse("Deposit successful");
    }
    @PutMapping("/witdraw/{amount}/{ID}")
    public ApiResponse witdrawMony(@PathVariable int amount ,@PathVariable int ID){
        customers.get(ID).setBalance( customers.get(ID).getBalance() - amount);
        return new ApiResponse("witdraw successful");
    }



}

