package com.example.bankmanagementapplication;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Customers {
   private int ID ;
    private String  Username ;
    private double   Balance;
}
